package com.example.appforhelpstudentswork

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class Lang {
    RU,
    EN
}

data class LocaleStrings(
    val signIn: String,
    val signUp: String,
    val continueWithGoogle: String,
    val continueWithVK: String,
    val continueWithEmail: String,
    val continueWithPhone: String,
    val email: String,
    val phone: String,
    val password: String,
    val next: String,
    val language: String,
    val fillQuestionnaire: String,
    val fullName: String,
    val birthDate: String,
    val studyPlace: String,
    val skills: String,
    val desiredPosition: String,
    val about: String,
    val uploadStudentId: String,
    val uploadPassport: String,
    val uploadResume: String,
    val feed: String,
    val search: String,
    val favorites: String,
    val applications: String,
    val profile: String,
    val vacancies: String,
    val saved: String,
    val myApplications: String,
    val searchHint: String,
    val all: String,
    val remote: String,
    val office: String,
    val hybrid: String,
    val fullTime: String,
    val partTime: String,
    val internship: String,
    val description: String,
    val requirements: String,
    val benefits: String,
    val respond: String,
    val responseSent: String,
    val editProfile: String,
    val settings: String,
    val logout: String,
    val changeBanner: String,
    val changeAvatar: String,
    val nickname: String,
    val myResume: String,
    val documents: String,
    val notUploaded: String,
    val uploaded: String,
    val views: String,
    val responses: String,
    val invites: String,
    val salary: String,
    val emptyFavorites: String,
    val emptyApplications: String,
    val welcome: String,
    val authMethod: String,
    val save: String,
    val mainInfo: String,
    val filesAndDocs: String
)

object Localization {

    // хранит русские тексты приложения
    val ru = LocaleStrings(
        signIn = "Войти",
        signUp = "Регистрация",
        continueWithGoogle = "Продолжить с Google",
        continueWithVK = "Продолжить с ВКонтакте",
        continueWithEmail = "Войти по почте",
        continueWithPhone = "Войти по телефону",
        email = "Email",
        phone = "Номер телефона",
        password = "Пароль",
        next = "Далее",
        language = "Язык",
        fillQuestionnaire = "Заполни анкету",
        fullName = "ФИО",
        birthDate = "Дата рождения",
        studyPlace = "Университет, факультет, курс",
        skills = "Навыки",
        desiredPosition = "Желаемая должность",
        about = "О себе",
        uploadStudentId = "Фото студенческого",
        uploadPassport = "Фото паспорта",
        uploadResume = "Загрузить резюме (PDF)",
        feed = "Лента",
        search = "Поиск",
        favorites = "Избранное",
        applications = "Отклики",
        profile = "Профиль",
        vacancies = "Вакансии",
        saved = "Сохранённое",
        myApplications = "Мои отклики",
        searchHint = "Профессия, компания...",
        all = "Все",
        remote = "Удалёнка",
        office = "Офис",
        hybrid = "Гибрид",
        fullTime = "Полная",
        partTime = "Частичная",
        internship = "Стажировка",
        description = "Описание",
        requirements = "Требования",
        benefits = "Что предлагаем",
        respond = "Откликнуться",
        responseSent = "Отклик отправлен",
        editProfile = "Редактировать",
        settings = "Настройки",
        logout = "Выйти из аккаунта",
        changeBanner = "Сменить баннер",
        changeAvatar = "Сменить фото",
        nickname = "Никнейм",
        myResume = "Моё резюме",
        documents = "Документы",
        notUploaded = "Не загружено",
        uploaded = "Загружено",
        views = "Просмотры",
        responses = "Отклики",
        invites = "Приглашения",
        salary = "Зарплата",
        emptyFavorites = "Нет избранных вакансий",
        emptyApplications = "Вы пока не откликались",
        welcome = "Добро пожаловать",
        authMethod = "Как вам удобнее войти?",
        save = "Сохранить",
        mainInfo = "Основная информация",
        filesAndDocs = "Файлы и документы"
    )

    // хранит английские тексты приложения
    val en = LocaleStrings(
        signIn = "Sign In",
        signUp = "Sign Up",
        continueWithGoogle = "Continue with Google",
        continueWithVK = "Continue with VK",
        continueWithEmail = "Continue with Email",
        continueWithPhone = "Continue with Phone",
        email = "Email",
        phone = "Phone number",
        password = "Password",
        next = "Next",
        language = "Language",
        fillQuestionnaire = "Fill out the form",
        fullName = "Full Name",
        birthDate = "Date of Birth",
        studyPlace = "University, Faculty, Year",
        skills = "Skills",
        desiredPosition = "Desired Position",
        about = "About me",
        uploadStudentId = "Student ID photo",
        uploadPassport = "Passport photo",
        uploadResume = "Upload Resume (PDF)",
        feed = "Feed",
        search = "Search",
        favorites = "Favorites",
        applications = "Applied",
        profile = "Profile",
        vacancies = "Vacancies",
        saved = "Saved",
        myApplications = "My Applications",
        searchHint = "Profession, company...",
        all = "All",
        remote = "Remote",
        office = "Office",
        hybrid = "Hybrid",
        fullTime = "Full-time",
        partTime = "Part-time",
        internship = "Internship",
        description = "Description",
        requirements = "Requirements",
        benefits = "What we offer",
        respond = "Apply",
        responseSent = "Applied",
        editProfile = "Edit",
        settings = "Settings",
        logout = "Log out",
        changeBanner = "Change banner",
        changeAvatar = "Change photo",
        nickname = "Nickname",
        myResume = "My Resume",
        documents = "Documents",
        notUploaded = "Not uploaded",
        uploaded = "Uploaded",
        views = "Views",
        responses = "Responses",
        invites = "Invitations",
        salary = "Salary",
        emptyFavorites = "No favorite vacancies",
        emptyApplications = "You haven't applied yet",
        welcome = "Welcome",
        authMethod = "How would you like to sign in?",
        save = "Save",
        mainInfo = "Basic information",
        filesAndDocs = "Files and documents"
    )
}

// переводит формат работы вакансии на выбранный язык
fun formatLabel(format: String, s: LocaleStrings): String = when (format) {
    "remote" -> s.remote
    "office" -> s.office
    "hybrid" -> s.hybrid
    else -> format
}

val LocalStrings = compositionLocalOf { Localization.ru }
val LocalLang = compositionLocalOf { mutableStateOf(Lang.RU) }

data class StudentProfile(
    val fullName: String = "",
    val nickname: String = "@cyber_user",
    val birthDate: String = "",
    val studyPlace: String = "",
    val skills: String = "",
    val desiredPosition: String = "",
    val about: String = "",
    val avatar: String = "👽",
    val avatarUri: Uri? = null,
    val bannerUri: Uri? = null,
    val studentIdUri: Uri? = null,
    val passportUri: Uri? = null,
    val resumeUri: Uri? = null
)

data class Vacancy(
    val id: Int,
    val company: String,
    val title: String,
    val city: String,
    val salaryFrom: Int,
    val salaryTo: Int,
    val format: String,
    val workType: String,
    val category: String,
    val description: String,
    val requirements: List<String>,
    val benefits: List<String>,
    val logo: String,
    val isHot: Boolean = false,
    val companyRating: Float = 4.5f
)

object DemoData {

    // создаёт тестовые вакансии (всего 23 штуки)
    val vacancies = listOf(
        Vacancy(
            id = 1,
            company = "Yandex",
            title = "Junior Android Developer",
            city = "Москва",
            salaryFrom = 80000,
            salaryTo = 120000,
            format = "hybrid",
            workType = "fullTime",
            category = "IT",
            description = "Присоединяйся к команде мобильной разработки. Будем делать продукты для миллионов пользователей.",
            requirements = listOf("Kotlin", "Android SDK", "Git", "Основы Jetpack Compose"),
            benefits = listOf("ДМС со стоматологией", "Гибкий график", "Обучение", "Корпоративные скидки"),
            logo = "Y",
            isHot = true,
            companyRating = 4.8f
        ),
        Vacancy(
            id = 2,
            company = "Tinkoff",
            title = "UI/UX Designer Intern",
            city = "Remote",
            salaryFrom = 60000,
            salaryTo = 90000,
            format = "remote",
            workType = "internship",
            category = "Design",
            description = "Стажировка в команде дизайна финтех-продуктов. Реальные задачи с первого дня.",
            requirements = listOf("Figma", "UX исследования", "Портфолио", "Английский B1+"),
            benefits = listOf("Удалёнка", "Наставник", "Оффер лучшим", "Техника от компании"),
            logo = "T",
            companyRating = 4.9f
        ),
        Vacancy(
            id = 3,
            company = "VK",
            title = "SMM Manager",
            city = "СПб",
            salaryFrom = 50000,
            salaryTo = 80000,
            format = "office",
            workType = "partTime",
            category = "Marketing",
            description = "Ведение соцсетей, создание контента, работа с инфлюенсерами.",
            requirements = listOf("Грамотность", "Креатив", "Опыт ведения SMM", "Знание трендов"),
            benefits = listOf("Молодая команда", "Крутой офис", "Мерч", "Корпоративы"),
            logo = "V",
            companyRating = 4.6f
        ),
        Vacancy(
            id = 4,
            company = "Google",
            title = "Software Engineer",
            city = "Москва",
            salaryFrom = 150000,
            salaryTo = 250000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Разработка масштабируемых сервисов для миллионов пользователей. Работа в международной команде.",
            requirements = listOf("Java/Kotlin", "Алгоритмы", "Data Structures", "Английский C1"),
            benefits = listOf("Релокация", "Акции", "Бесплатное питание", "Фитнес"),
            logo = "G",
            isHot = true,
            companyRating = 4.9f
        ),
        Vacancy(
            id = 5,
            company = "Sber",
            title = "Data Analyst",
            city = "Москва",
            salaryFrom = 90000,
            salaryTo = 140000,
            format = "hybrid",
            workType = "fullTime",
            category = "Analytics",
            description = "Анализ больших данных, построение дашбордов, поиск инсайтов для бизнеса.",
            requirements = listOf("SQL", "Python", "Tableau", "Статистика"),
            benefits = listOf("ДМС", "Спортзал", "Обучение", "Бонусы"),
            logo = "S",
            companyRating = 4.7f
        ),
        Vacancy(
            id = 6,
            company = "Mail.ru",
            title = "Go Developer",
            city = "СПб",
            salaryFrom = 120000,
            salaryTo = 180000,
            format = "remote",
            workType = "fullTime",
            category = "IT",
            description = "Разработка высоконагруженных сервисов на Go. Микросервисная архитектура.",
            requirements = listOf("Go", "Docker", "Kubernetes", "PostgreSQL"),
            benefits = listOf("Удалёнка", "Гибкий график", "ДМС", "Курсы"),
            logo = "M",
            companyRating = 4.5f
        ),
        Vacancy(
            id = 7,
            company = "Ozon",
            title = "Java Developer",
            city = "Москва",
            salaryFrom = 140000,
            salaryTo = 200000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Разработка backend для крупнейшего маркетплейса России.",
            requirements = listOf("Java 17+", "Spring Boot", "Hibernate", "Kafka"),
            benefits = listOf("ДМС", "Скидки на Ozon", "Спорт", "Обучение"),
            logo = "O",
            isHot = true,
            companyRating = 4.6f
        ),
        Vacancy(
            id = 8,
            company = "Wildberries",
            title = "Frontend Developer",
            city = "Москва",
            salaryFrom = 100000,
            salaryTo = 150000,
            format = "remote",
            workType = "fullTime",
            category = "IT",
            description = "Создание интерфейсов для самого посещаемого сайта в России.",
            requirements = listOf("React", "TypeScript", "Redux", "Webpack"),
            benefits = listOf("Удалёнка", "Гибкий график", "ДМС", "Премии"),
            logo = "W",
            companyRating = 4.3f
        ),
        Vacancy(
            id = 9,
            company = "EPAM",
            title = "QA Automation Engineer",
            city = "СПб",
            salaryFrom = 80000,
            salaryTo = 130000,
            format = "hybrid",
            workType = "fullTime",
            category = "IT",
            description = "Автоматизация тестирования веб-приложений для международных клиентов.",
            requirements = listOf("Java", "Selenium", "TestNG", "CI/CD"),
            benefits = listOf("Английский", "Релокация", "Обучение", "ДМС"),
            logo = "E",
            companyRating = 4.4f
        ),
        Vacancy(
            id = 10,
            company = "Kaspersky",
            title = "C++ Developer",
            city = "Москва",
            salaryFrom = 130000,
            salaryTo = 190000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Разработка антивирусного ПО. Работа с низкоуровневым кодом и безопасностью.",
            requirements = listOf("C++", "STL", "Multithreading", "Windows API"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Гибкий график"),
            logo = "K",
            companyRating = 4.8f
        ),
        Vacancy(
            id = 11,
            company = "Avito",
            title = "Product Manager",
            city = "Москва",
            salaryFrom = 120000,
            salaryTo = 180000,
            format = "hybrid",
            workType = "fullTime",
            category = "Management",
            description = "Управление продуктом, работа с метриками, развитие функциональности.",
            requirements = listOf("Аналитика", "A/B тесты", "Product Vision", "Коммуникация"),
            benefits = listOf("ДМС", "Опционы", "Обучение", "Гибрид"),
            logo = "A",
            companyRating = 4.7f
        ),
        Vacancy(
            id = 12,
            company = "Alfa-Bank",
            title = "Business Analyst",
            city = "Москва",
            salaryFrom = 90000,
            salaryTo = 140000,
            format = "office",
            workType = "fullTime",
            category = "Analytics",
            description = "Сбор требований, написание ТЗ, взаимодействие с командой разработки.",
            requirements = listOf("UML", "BPMN", "SQL", "Jira"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Премии"),
            logo = "A",
            companyRating = 4.5f
        ),
        Vacancy(
            id = 13,
            company = "MTS",
            title = "DevOps Engineer",
            city = "Москва",
            salaryFrom = 150000,
            salaryTo = 220000,
            format = "remote",
            workType = "fullTime",
            category = "IT",
            description = "Поддержка и развитие инфраструктуры, автоматизация развертывания.",
            requirements = listOf("Linux", "Docker", "Kubernetes", "Ansible"),
            benefits = listOf("Удалёнка", "ДМС", "Обучение", "Бонусы"),
            logo = "M",
            isHot = true,
            companyRating = 4.6f
        ),
        Vacancy(
            id = 14,
            company = "Megafon",
            title = "Graphic Designer",
            city = "СПб",
            salaryFrom = 60000,
            salaryTo = 90000,
            format = "office",
            workType = "fullTime",
            category = "Design",
            description = "Создание графических материалов для маркетинга и рекламы.",
            requirements = listOf("Photoshop", "Illustrator", "Figma", "Портфолио"),
            benefits = listOf("ДМС", "Корпоративы", "Мерч", "Обучение"),
            logo = "M",
            companyRating = 4.4f
        ),
        Vacancy(
            id = 15,
            company = "Beeline",
            title = "SEO Specialist",
            city = "Remote",
            salaryFrom = 50000,
            salaryTo = 80000,
            format = "remote",
            workType = "fullTime",
            category = "Marketing",
            description = "Продвижение сайта в поисковых системах, работа с контентом и ссылками.",
            requirements = listOf("SEO", "Яндекс.Метрика", "Google Analytics", "Контент"),
            benefits = listOf("Удалёнка", "Гибкий график", "ДМС", "Обучение"),
            logo = "B",
            companyRating = 4.2f
        ),
        Vacancy(
            id = 16,
            company = "Rosbank",
            title = "System Administrator",
            city = "Москва",
            salaryFrom = 70000,
            salaryTo = 110000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Поддержка серверной инфраструктуры, настройка сетевого оборудования.",
            requirements = listOf("Windows Server", "Linux", "Active Directory", "Сети"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Премии"),
            logo = "R",
            companyRating = 4.1f
        ),
        Vacancy(
            id = 17,
            company = "Lamoda",
            title = "Motion Designer",
            city = "Москва",
            salaryFrom = 80000,
            salaryTo = 120000,
            format = "hybrid",
            workType = "fullTime",
            category = "Design",
            description = "Создание анимации и видеоконтента для рекламных кампаний.",
            requirements = listOf("After Effects", "Premiere Pro", "Cinema 4D", "Портфолио"),
            benefits = listOf("ДМС", "Скидки", "Обучение", "Гибрид"),
            logo = "L",
            companyRating = 4.5f
        ),
        Vacancy(
            id = 18,
            company = "X5 Group",
            title = "Python Developer",
            city = "Москва",
            salaryFrom = 110000,
            salaryTo = 160000,
            format = "remote",
            workType = "fullTime",
            category = "IT",
            description = "Разработка внутренних сервисов и автоматизация процессов.",
            requirements = listOf("Python", "Django", "FastAPI", "PostgreSQL"),
            benefits = listOf("Удалёнка", "ДМС", "Обучение", "Бонусы"),
            logo = "X",
            companyRating = 4.6f
        ),
        Vacancy(
            id = 19,
            company = "SberMarket",
            title = "Android Developer",
            city = "СПб",
            salaryFrom = 130000,
            salaryTo = 180000,
            format = "remote",
            workType = "fullTime",
            category = "IT",
            description = "Разработка мобильного приложения для доставки продуктов.",
            requirements = listOf("Kotlin", "Coroutines", "Dagger", "Retrofit"),
            benefits = listOf("Удалёнка", "ДМС", "Спорт", "Обучение"),
            logo = "S",
            isHot = true,
            companyRating = 4.7f
        ),
        Vacancy(
            id = 20,
            company = "Yandex",
            title = "Machine Learning Engineer",
            city = "Москва",
            salaryFrom = 180000,
            salaryTo = 280000,
            format = "hybrid",
            workType = "fullTime",
            category = "IT",
            description = "Разработка и внедрение ML-моделей в продукты Яндекса.",
            requirements = listOf("Python", "PyTorch", "ML", "Математика"),
            benefits = listOf("ДМС", "Опционы", "Обучение", "Гибрид"),
            logo = "Y",
            companyRating = 4.9f
        ),
        Vacancy(
            id = 21,
            company = "VK",
            title = "iOS Developer",
            city = "СПб",
            salaryFrom = 140000,
            salaryTo = 200000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Разработка приложений для экосистемы VK на Swift.",
            requirements = listOf("Swift", "SwiftUI", "Combine", "MVP/MVVM"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Премии"),
            logo = "V",
            companyRating = 4.6f
        ),
        Vacancy(
            id = 22,
            company = "Tinkoff",
            title = "1C Programmer",
            city = "Москва",
            salaryFrom = 100000,
            salaryTo = 150000,
            format = "office",
            workType = "fullTime",
            category = "IT",
            description = "Автоматизация бизнес-процессов на платформе 1С.",
            requirements = listOf("1С", "SQL", "ERP", "Бухгалтерия"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Бонусы"),
            logo = "T",
            companyRating = 4.5f
        ),
        Vacancy(
            id = 23,
            company = "Sber",
            title = "HR Manager",
            city = "Москва",
            salaryFrom = 70000,
            salaryTo = 100000,
            format = "office",
            workType = "fullTime",
            category = "HR",
            description = "Подбор персонала, адаптация новых сотрудников, кадровое делопроизводство.",
            requirements = listOf("Подбор", "Интервью", "HRIS", "Коммуникация"),
            benefits = listOf("ДМС", "Спорт", "Обучение", "Премии"),
            logo = "S",
            companyRating = 4.7f
        )
    )
}

object NeonPalette {
    val DeepSpace = Color(0xFF090416)
    val NeonPurple = Color(0xFF9D00FF)
    val NeonCyan = Color(0xFF00F0FF)
    val NeonPink = Color(0xFFFF007F)
    val NeonGreen = Color(0xFF00FFA3)

    val GlassWhite = Color.White
    val GlassSecondary = Color(0xFFA59BBD)
    val SurfaceLow = Color.White.copy(alpha = 0.05f)
    val GlassBorder = Color.White.copy(alpha = 0.15f)
}

class MainActivity : ComponentActivity() {

    // запускает приложение
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            val langState = rememberSaveable {
                mutableStateOf(Lang.RU)
            }

            CompositionLocalProvider(
                LocalLang provides langState,
                LocalStrings provides if (langState.value == Lang.RU) {
                    Localization.ru
                } else {
                    Localization.en
                }
            ) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        background = NeonPalette.DeepSpace,
                        surface = NeonPalette.SurfaceLow,
                        onBackground = NeonPalette.GlassWhite,
                        onSurface = NeonPalette.GlassWhite,
                        primary = NeonPalette.NeonCyan
                    )
                ) {
                    // задаёт белый цвет текста по умолчанию
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = NeonPalette.DeepSpace,
                        contentColor = NeonPalette.GlassWhite
                    ) {
                        AppRoot()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AppRoot() {

    // управляет экранами приложения
    var screen by rememberSaveable {
        mutableStateOf("lang")
    }

    // хранит режим редактирования профиля
    var editMode by rememberSaveable {
        mutableStateOf(false)
    }

    // хранит активную вкладку
    var selectedTab by rememberSaveable {
        mutableIntStateOf(0)
    }

    // хранит профиль пользователя
    var currentUser by remember {
        mutableStateOf(StudentProfile())
    }

    // хранит id выбранной вакансии
    var selectedVacancyId by rememberSaveable {
        mutableStateOf<Int?>(null)
    }
    val selectedVacancy = DemoData.vacancies.find { it.id == selectedVacancyId }

    // сохраняет список Int при повороте экрана
    val idListSaver = listSaver<SnapshotStateList<Int>, Int>(
        save = { it.toList() },
        restore = { it.toMutableStateList() }
    )

    // хранит избранные вакансии
    val favoriteIds = rememberSaveable(saver = idListSaver) {
        mutableStateListOf<Int>()
    }

    // хранит отправленные отклики
    val appliedIds = rememberSaveable(saver = idListSaver) {
        mutableStateListOf<Int>()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NeonPalette.DeepSpace)
    ) {
        AnimatedBackground()

        // обрабатывает системную кнопку назад
        BackHandler(
            enabled = screen !in listOf("lang", "auth", "home")
        ) {
            screen = when (screen) {
                "authEmail", "authPhone" -> "auth"
                "questionnaire" -> if (editMode) "home" else "auth"
                "detail", "settings" -> "home"
                else -> "home"
            }
        }

        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                fadeIn(
                    animationSpec = tween(400)
                ) togetherWith fadeOut(
                    animationSpec = tween(400)
                )
            },
            label = "navigation"
        ) { currentScreen ->

            when (currentScreen) {

                "lang" -> {
                    LanguageScreen(
                        onNext = {
                            screen = "auth"
                        }
                    )
                }

                "auth" -> {
                    AuthHubScreen(
                        onMethod = { method ->
                            screen = when (method) {
                                "email" -> "authEmail"
                                "phone" -> "authPhone"
                                else -> {
                                    editMode = false
                                    "questionnaire"
                                }
                            }
                        }
                    )
                }

                "authEmail",
                "authPhone" -> {
                    SimpleAuthScreen(
                        type = currentScreen,
                        onBack = {
                            screen = "auth"
                        },
                        onDone = {
                            editMode = false
                            screen = "questionnaire"
                        }
                    )
                }

                "questionnaire" -> {
                    QuestionnaireScreen(
                        initial = currentUser,
                        editMode = editMode,
                        onDone = {
                            currentUser = it
                            screen = "home"
                        },
                        onBack = {
                            screen = if (editMode) {
                                "home"
                            } else {
                                "auth"
                            }
                        }
                    )
                }

                "home" -> {
                    HomeScreen(
                        selectedTab = selectedTab,
                        onTab = {
                            selectedTab = it
                        },
                        user = currentUser,
                        favIds = favoriteIds,
                        appIds = appliedIds,
                        onFav = { id ->
                            if (favoriteIds.contains(id)) {
                                favoriteIds.remove(id)
                            } else {
                                favoriteIds.add(id)
                            }
                        },
                        onVac = {
                            selectedVacancyId = it.id
                            screen = "detail"
                        },
                        onEdit = {
                            editMode = true
                            screen = "questionnaire"
                        },
                        onSettings = {
                            screen = "settings"
                        }
                    )
                }

                "detail" -> {
                    selectedVacancy?.let { vacancy ->
                        VacancyDetailScreen(
                            vacancy = vacancy,
                            isFav = favoriteIds.contains(vacancy.id),
                            isApplied = appliedIds.contains(vacancy.id),
                            onBack = {
                                screen = "home"
                            },
                            onFav = {
                                if (favoriteIds.contains(vacancy.id)) {
                                    favoriteIds.remove(vacancy.id)
                                } else {
                                    favoriteIds.add(vacancy.id)
                                }
                            },
                            onApply = {
                                if (!appliedIds.contains(vacancy.id)) {
                                    appliedIds.add(vacancy.id)
                                }
                            }
                        )
                    }
                }

                "settings" -> {
                    SettingsScreen(
                        onBack = {
                            screen = "home"
                        },
                        onLogout = {
                            // при выходе сбрасываем данные прошлого пользователя
                            currentUser = StudentProfile()
                            favoriteIds.clear()
                            appliedIds.clear()
                            selectedVacancyId = null
                            editMode = false
                            selectedTab = 0
                            screen = "lang"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AnimatedBackground() {

    // создаёт анимированный фон
    val infiniteTransition = rememberInfiniteTransition(
        label = "background"
    )

    val offset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 50f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 8000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offset1"
    )

    val offset2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -40f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 10000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offset2"
    )

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(
                    x = (-80 + offset1).dp,
                    y = (-50).dp
                )
                .size(300.dp)
                .blur(120.dp)
                .background(
                    NeonPalette.NeonPurple.copy(alpha = 0.4f),
                    CircleShape
                )
        )

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(
                    x = (50 + offset2).dp,
                    y = 100.dp
                )
                .size(350.dp)
                .blur(140.dp)
                .background(
                    NeonPalette.NeonCyan.copy(alpha = 0.3f),
                    CircleShape
                )
        )

        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(
                    x = (-100).dp,
                    y = (offset1 * 2).dp
                )
                .size(200.dp)
                .blur(100.dp)
                .background(
                    NeonPalette.NeonPink.copy(alpha = 0.2f),
                    CircleShape
                )
        )
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    padding: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {

    // создаёт стеклянную карточку
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = 0.03f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.2f),
                        Color.White.copy(alpha = 0.05f)
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(padding),
        content = content
    )
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    outlined: Boolean = false,
    enabled: Boolean = true,
    accentColor: Color = NeonPalette.NeonCyan
) {

    // создаёт неоновую кнопку
    val gradient = Brush.horizontalGradient(
        listOf(
            NeonPalette.NeonPurple,
            accentColor
        )
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                when {
                    outlined -> SolidColor(Color.Transparent)
                    !enabled -> SolidColor(NeonPalette.SurfaceLow)
                    else -> gradient
                }
            )
            .border(
                width = 1.5.dp,
                brush = if (outlined) {
                    gradient
                } else if (!enabled) {
                    SolidColor(NeonPalette.GlassBorder)
                } else {
                    Brush.linearGradient(
                        listOf(
                            Color.Transparent,
                            Color.Transparent
                        )
                    )
                },
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(enabled = enabled) {
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (enabled) {
                NeonPalette.GlassWhite
            } else {
                NeonPalette.GlassSecondary
            },
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun GlassInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    hint: String = "",
    singleLine: Boolean = true,
    minLines: Int = 1,
    isPassword: Boolean = false
) {

    // создаёт поле ввода
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = NeonPalette.GlassSecondary,
            modifier = Modifier.padding(
                start = 4.dp,
                bottom = 6.dp
            )
        )

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = {
                Text(
                    text = hint,
                    color = NeonPalette.GlassSecondary.copy(alpha = 0.5f)
                )
            },
            singleLine = singleLine,
            minLines = minLines,
            shape = RoundedCornerShape(14.dp),
            visualTransformation = if (isPassword) {
                PasswordVisualTransformation()
            } else {
                VisualTransformation.None
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NeonPalette.SurfaceLow,
                unfocusedContainerColor = NeonPalette.SurfaceLow,
                focusedBorderColor = NeonPalette.NeonCyan,
                unfocusedBorderColor = NeonPalette.GlassBorder,
                cursorColor = NeonPalette.NeonCyan
            )
        )
    }
}

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    action: (@Composable () -> Unit)? = null
) {

    // создаёт верхнюю панель
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                WindowInsets.statusBars.asPaddingValues()
            )
            .padding(
                horizontal = 20.dp,
                vertical = 12.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        NeonPalette.SurfaceLow
                    )
                    .border(
                        1.dp,
                        NeonPalette.GlassBorder,
                        CircleShape
                    )
                    .clickable {
                        onBack()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "←",
                    color = NeonPalette.NeonCyan,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(
                modifier = Modifier.width(16.dp)
            )
        }

        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = NeonPalette.GlassWhite,
            modifier = Modifier.weight(1f)
        )

        action?.invoke()
    }
}

@Composable
fun LanguageScreen(
    onNext: () -> Unit
) {

    // показывает выбор языка
    val langState = LocalLang.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "🌐",
                fontSize = 64.sp
            )

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Text(
                text = "CyberJob",
                fontSize = 40.sp,
                fontWeight = FontWeight.Black,
                color = NeonPalette.GlassWhite,
                letterSpacing = 2.sp
            )

            Spacer(
                modifier = Modifier.height(48.dp)
            )

            LangOption(
                flag = "🇷🇺",
                title = "Русский",
                selected = langState.value == Lang.RU,
                onClick = {
                    langState.value = Lang.RU
                }
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            LangOption(
                flag = "🇬🇧",
                title = "English",
                selected = langState.value == Lang.EN,
                onClick = {
                    langState.value = Lang.EN
                }
            )

            Spacer(
                modifier = Modifier.height(40.dp)
            )

            NeonButton(
                text = if (langState.value == Lang.RU) {
                    "Продолжить"
                } else {
                    "Continue"
                },
                onClick = onNext
            )
        }
    }
}

@Composable
fun LangOption(
    flag: String,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {

    // создаёт кнопку выбора языка
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (selected) {
                    NeonPalette.NeonPurple.copy(alpha = 0.2f)
                } else {
                    NeonPalette.SurfaceLow
                }
            )
            .border(
                width = 1.5.dp,
                color = if (selected) {
                    NeonPalette.NeonCyan
                } else {
                    NeonPalette.GlassBorder
                },
                shape = RoundedCornerShape(16.dp)
            )
            .clickable {
                onClick()
            }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = flag,
            fontSize = 32.sp
        )

        Spacer(
            modifier = Modifier.width(16.dp)
        )

        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = NeonPalette.GlassWhite,
            modifier = Modifier.weight(1f)
        )

        if (selected) {
            Text(
                text = "✓",
                color = NeonPalette.NeonCyan,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun AuthHubScreen(
    onMethod: (String) -> Unit
) {

    // показывает способы входа
    val s = LocalStrings.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                NeonPalette.NeonPurple,
                                NeonPalette.NeonCyan
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "⚡",
                    fontSize = 40.sp
                )
            }

            Spacer(
                modifier = Modifier.height(24.dp)
            )

            Text(
                text = s.welcome,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(40.dp)
            )

            SocialBtn(
                icon = "G",
                text = s.continueWithGoogle,
                color = Color(0xFF4285F4),
                onClick = {
                    onMethod("google")
                }
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            SocialBtn(
                icon = "VK",
                text = s.continueWithVK,
                color = Color(0xFF0077FF),
                onClick = {
                    onMethod("vk")
                }
            )

            Spacer(
                modifier = Modifier.height(24.dp)
            )

            SocialBtn(
                icon = "✉",
                text = s.continueWithEmail,
                color = NeonPalette.NeonPink,
                onClick = {
                    onMethod("email")
                }
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            SocialBtn(
                icon = "📱",
                text = s.continueWithPhone,
                color = NeonPalette.NeonGreen,
                onClick = {
                    onMethod("phone")
                }
            )
        }
    }
}

@Composable
fun SocialBtn(
    icon: String,
    text: String,
    color: Color,
    onClick: () -> Unit
) {

    // создаёт кнопку входа
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(NeonPalette.SurfaceLow)
            .border(
                1.dp,
                NeonPalette.GlassBorder,
                RoundedCornerShape(14.dp)
            )
            .clickable {
                onClick()
            }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f))
                .border(
                    1.dp,
                    color,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = icon,
                color = color,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(
            modifier = Modifier.width(14.dp)
        )

        Text(
            text = text,
            color = NeonPalette.GlassWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun SimpleAuthScreen(
    type: String,
    onBack: () -> Unit,
    onDone: () -> Unit
) {

    // обрабатывает вход через почту или телефон
    val s = LocalStrings.current

    var input by remember {
        mutableStateOf("")
    }

    var pass by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopBar(
            title = if (type == "authEmail") {
                s.continueWithEmail
            } else {
                s.continueWithPhone
            },
            onBack = onBack
        )

        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            GlassInput(
                value = input,
                onValueChange = {
                    input = it
                },
                label = if (type == "authEmail") {
                    s.email
                } else {
                    s.phone
                }
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            GlassInput(
                value = pass,
                onValueChange = {
                    pass = it
                },
                label = s.password,
                isPassword = true
            )

            Spacer(
                modifier = Modifier.height(32.dp)
            )

            NeonButton(
                text = s.next,
                onClick = {
                    onDone()
                },
                enabled = input.isNotBlank() && pass.isNotBlank()
            )
        }
    }
}

@Composable
fun QuestionnaireScreen(
    initial: StudentProfile,
    editMode: Boolean,
    onDone: (StudentProfile) -> Unit,
    onBack: () -> Unit
) {

    // создаёт и редактирует профиль
    val s = LocalStrings.current

    var p by remember(initial) {
        mutableStateOf(initial)
    }

    // выбирает фотографию аватара
    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            p = p.copy(
                avatarUri = uri
            )
        }
    }

    // выбирает фотографию баннера
    val bannerPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            p = p.copy(
                bannerUri = uri
            )
        }
    }

    // выбирает студенческий билет
    val studentIdPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            p = p.copy(
                studentIdUri = uri
            )
        }
    }

    // выбирает паспорт
    val passportPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            p = p.copy(
                passportUri = uri
            )
        }
    }

    // выбирает резюме
    val resumePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            p = p.copy(
                resumeUri = uri
            )
        }
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopBar(
            title = if (editMode) {
                s.editProfile
            } else {
                s.fillQuestionnaire
            },
            onBack = onBack
        )

        LazyColumn(
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 20.dp,
                bottom = 20.dp + WindowInsets.navigationBars
                    .asPaddingValues()
                    .calculateBottomPadding()
            ),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            item {
                GlassCard(
                    padding = 0.dp
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(
                                    RoundedCornerShape(
                                        topStart = 24.dp,
                                        topEnd = 24.dp
                                    )
                                )
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            NeonPalette.NeonPurple,
                                            NeonPalette.NeonPink
                                        )
                                    )
                                )
                                .clickable {
                                    bannerPicker.launch("image/*")
                                }
                        ) {
                            p.bannerUri?.let { uri ->
                                UriImage(
                                    uri = uri,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Color.Black.copy(alpha = 0.5f)
                                    )
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "📷 ${s.changeBanner}",
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 20.dp)
                                .offset(y = 40.dp)
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(
                                    NeonPalette.DeepSpace
                                )
                                .border(
                                    3.dp,
                                    NeonPalette.DeepSpace,
                                    CircleShape
                                )
                                .clickable {
                                    avatarPicker.launch("image/*")
                                }
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(
                                                NeonPalette.NeonPurple,
                                                NeonPalette.NeonCyan
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatarUri = p.avatarUri
                                if (avatarUri != null) {
                                    UriImage(
                                        uri = avatarUri,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Text(
                                        text = p.avatar,
                                        fontSize = 40.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(
                        modifier = Modifier.height(50.dp)
                    )

                    Text(
                        text = "👆 ${s.changeAvatar}",
                        fontSize = 11.sp,
                        color = NeonPalette.GlassSecondary,
                        modifier = Modifier.padding(
                            start = 20.dp,
                            bottom = 16.dp
                        )
                    )
                }
            }

            item {
                Text(
                    text = s.mainInfo,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonPalette.NeonPurple
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                GlassInput(
                    value = p.fullName,
                    onValueChange = {
                        p = p.copy(
                            fullName = it
                        )
                    },
                    label = s.fullName
                )

                Spacer(
                    modifier = Modifier.height(10.dp)
                )

                GlassInput(
                    value = p.nickname,
                    onValueChange = {
                        p = p.copy(
                            nickname = it
                        )
                    },
                    label = s.nickname
                )

                Spacer(
                    modifier = Modifier.height(10.dp)
                )

                GlassInput(
                    value = p.studyPlace,
                    onValueChange = {
                        p = p.copy(
                            studyPlace = it
                        )
                    },
                    label = s.studyPlace
                )
            }

            item {
                Text(
                    text = s.filesAndDocs,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonPalette.NeonPink
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                DocUpload(
                    title = s.uploadStudentId,
                    uploaded = p.studentIdUri != null,
                    onClick = {
                        studentIdPicker.launch("image/*")
                    }
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                DocUpload(
                    title = s.uploadPassport,
                    uploaded = p.passportUri != null,
                    onClick = {
                        passportPicker.launch("image/*")
                    }
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                DocUpload(
                    title = s.uploadResume,
                    uploaded = p.resumeUri != null,
                    onClick = {
                        resumePicker.launch("application/pdf")
                    }
                )
            }

            item {
                NeonButton(
                    text = s.save,
                    onClick = {
                        onDone(p)
                    }
                )

                Spacer(
                    modifier = Modifier.height(20.dp)
                )
            }
        }
    }
}

@Composable
fun UriImage(
    uri: Uri,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    contentDescription: String? = null
) {

    // загружает изображение без сторонней библиотеки
    val context = LocalContext.current

    val imageBitmap by produceState<ImageBitmap?>(
        initialValue = null,
        key1 = uri
    ) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver
                    .openInputStream(uri)
                    ?.use { inputStream ->
                        BitmapFactory
                            .decodeStream(inputStream)
                            ?.asImageBitmap()
                    }
            }.getOrNull()
        }
    }

    if (imageBitmap != null) {
        Image(
            bitmap = imageBitmap!!,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    } else {
        Box(
            modifier = modifier.background(
                Brush.linearGradient(
                    listOf(
                        NeonPalette.NeonPurple,
                        NeonPalette.NeonCyan
                    )
                )
            )
        )
    }
}

@Composable
fun DocUpload(
    title: String,
    uploaded: Boolean,
    onClick: () -> Unit
) {

    // показывает загрузку документа
    val s = LocalStrings.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (uploaded) {
                    NeonPalette.NeonGreen.copy(alpha = 0.1f)
                } else {
                    NeonPalette.SurfaceLow
                }
            )
            .border(
                width = 1.dp,
                color = if (uploaded) {
                    NeonPalette.NeonGreen.copy(alpha = 0.5f)
                } else {
                    NeonPalette.GlassBorder
                },
                shape = RoundedCornerShape(14.dp)
            )
            .clickable {
                onClick()
            }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                color = NeonPalette.GlassWhite,
                fontSize = 14.sp
            )

            Text(
                text = if (uploaded) {
                    s.uploaded
                } else {
                    s.notUploaded
                },
                fontSize = 11.sp,
                color = if (uploaded) {
                    NeonPalette.NeonGreen
                } else {
                    NeonPalette.GlassSecondary
                }
            )
        }

        Text(
            text = if (uploaded) {
                "✓"
            } else {
                "+"
            },
            fontSize = 24.sp,
            color = if (uploaded) {
                NeonPalette.NeonGreen
            } else {
                NeonPalette.NeonCyan
            }
        )
    }
}

@Composable
fun HomeScreen(
    selectedTab: Int,
    onTab: (Int) -> Unit,
    user: StudentProfile,
    favIds: List<Int>,
    appIds: List<Int>,
    onFav: (Int) -> Unit,
    onVac: (Vacancy) -> Unit,
    onEdit: () -> Unit,
    onSettings: () -> Unit
) {

    // показывает основные вкладки приложения
    val navBarPadding = WindowInsets.navigationBars
        .asPaddingValues()
        .calculateBottomPadding()

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 104.dp + navBarPadding)
        ) {
            when (selectedTab) {
                0 -> FeedTab(
                    favIds = favIds,
                    appIds = appIds,
                    onFav = onFav,
                    onVac = onVac
                )

                1 -> FavTab(
                    favIds = favIds,
                    appIds = appIds,
                    onFav = onFav,
                    onVac = onVac
                )

                2 -> AppTab(
                    appIds = appIds,
                    onVac = onVac
                )

                3 -> ProfileTab(
                    user = user,
                    favs = favIds.size,
                    apps = appIds.size,
                    onEdit = onEdit,
                    onSettings = onSettings
                )
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(
                    bottom = 20.dp + navBarPadding,
                    start = 20.dp,
                    end = 20.dp
                )
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Color.Black.copy(alpha = 0.7f)
                )
                .border(
                    1.dp,
                    NeonPalette.GlassBorder,
                    RoundedCornerShape(32.dp)
                )
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val tabs = listOf(
                    "🏠" to LocalStrings.current.feed,
                    "♥" to LocalStrings.current.favorites,
                    "✉" to LocalStrings.current.applications,
                    "👤" to LocalStrings.current.profile
                )

                tabs.forEachIndexed { index, tab ->
                    val selected = selectedTab == index

                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                onTab(index)
                            }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = tab.first,
                            fontSize = 20.sp,
                            color = if (selected) {
                                NeonPalette.NeonCyan
                            } else {
                                NeonPalette.GlassSecondary
                            }
                        )

                        Text(
                            text = tab.second,
                            fontSize = 9.sp,
                            color = if (selected) {
                                NeonPalette.NeonCyan
                            } else {
                                NeonPalette.GlassSecondary
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeedTab(
    favIds: List<Int>,
    appIds: List<Int>,
    onFav: (Int) -> Unit,
    onVac: (Vacancy) -> Unit
) {

    // показывает все вакансии
    val s = LocalStrings.current

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = WindowInsets.statusBars
                .asPaddingValues()
                .calculateTopPadding() + 16.dp,
            bottom = 20.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = s.vacancies,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
        }

        items(DemoData.vacancies) { vacancy ->
            VacancyCard(
                vacancy = vacancy,
                isFav = favIds.contains(vacancy.id),
                isApplied = appIds.contains(vacancy.id),
                onFav = {
                    onFav(vacancy.id)
                },
                onClick = {
                    onVac(vacancy)
                }
            )
        }
    }
}

@Composable
fun FavTab(
    favIds: List<Int>,
    appIds: List<Int>,
    onFav: (Int) -> Unit,
    onVac: (Vacancy) -> Unit
) {

    // показывает избранные вакансии
    val s = LocalStrings.current

    val favorites = DemoData.vacancies.filter {
        favIds.contains(it.id)
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = WindowInsets.statusBars
                .asPaddingValues()
                .calculateTopPadding() + 16.dp,
            bottom = 20.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = s.favorites,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
        }

        if (favorites.isEmpty()) {
            item {
                Text(
                    text = s.emptyFavorites,
                    color = NeonPalette.GlassSecondary,
                    modifier = Modifier.padding(top = 40.dp)
                )
            }
        }

        items(favorites) { vacancy ->
            VacancyCard(
                vacancy = vacancy,
                isFav = true,
                isApplied = appIds.contains(vacancy.id),
                onFav = {
                    onFav(vacancy.id)
                },
                onClick = {
                    onVac(vacancy)
                }
            )
        }
    }
}

@Composable
fun AppTab(
    appIds: List<Int>,
    onVac: (Vacancy) -> Unit
) {

    // показывает отправленные отклики
    val s = LocalStrings.current

    val applications = DemoData.vacancies.filter {
        appIds.contains(it.id)
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = WindowInsets.statusBars
                .asPaddingValues()
                .calculateTopPadding() + 16.dp,
            bottom = 20.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = s.applications,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
        }

        if (applications.isEmpty()) {
            item {
                Text(
                    text = s.emptyApplications,
                    color = NeonPalette.GlassSecondary,
                    modifier = Modifier.padding(top = 40.dp)
                )
            }
        }

        items(applications) { vacancy ->
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        onVac(vacancy)
                    }
            ) {
                Text(
                    text = "✓ ${vacancy.title} — ${vacancy.company}",
                    color = NeonPalette.NeonGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ProfileTab(
    user: StudentProfile,
    favs: Int,
    apps: Int,
    onEdit: () -> Unit,
    onSettings: () -> Unit
) {

    // показывает профиль пользователя
    val s = LocalStrings.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    NeonPalette.NeonPurple,
                                    NeonPalette.NeonCyan
                                )
                            )
                        )
                ) {
                    user.bannerUri?.let { uri ->
                        UriImage(
                            uri = uri,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Row(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(
                                WindowInsets.statusBars
                                    .asPaddingValues()
                            )
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    Color.Black.copy(alpha = 0.5f)
                                )
                                .clickable {
                                    onSettings()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "⚙",
                                color = Color.White
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 20.dp)
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(
                            NeonPalette.DeepSpace
                        )
                        .border(
                            4.dp,
                            NeonPalette.DeepSpace,
                            CircleShape
                        )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        NeonPalette.NeonPurple,
                                        NeonPalette.NeonCyan
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        val avatarUri = user.avatarUri
                        if (avatarUri != null) {
                            UriImage(
                                uri = avatarUri,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = user.avatar,
                                fontSize = 40.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Text(
                    text = user.fullName.ifBlank {
                        "Neo"
                    },
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = user.nickname.ifBlank {
                        "@cyber_user"
                    },
                    fontSize = 14.sp,
                    color = NeonPalette.NeonCyan
                )

                Spacer(
                    modifier = Modifier.height(16.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GlassCard(
                        modifier = Modifier.weight(1f),
                        padding = 12.dp
                    ) {
                        Text(
                            text = apps.toString(),
                            fontSize = 24.sp,
                            color = NeonPalette.NeonPink,
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            text = s.responses,
                            fontSize = 10.sp,
                            color = NeonPalette.GlassSecondary
                        )
                    }

                    GlassCard(
                        modifier = Modifier.weight(1f),
                        padding = 12.dp
                    ) {
                        Text(
                            text = favs.toString(),
                            fontSize = 24.sp,
                            color = NeonPalette.NeonCyan,
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            text = s.favorites,
                            fontSize = 10.sp,
                            color = NeonPalette.GlassSecondary
                        )
                    }
                }

                Spacer(
                    modifier = Modifier.height(20.dp)
                )

                NeonButton(
                    text = s.editProfile,
                    onClick = onEdit,
                    outlined = true
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                // Добавленная кнопка Настроек
                NeonButton(
                    text = s.settings,
                    onClick = onSettings,
                    outlined = true,
                    accentColor = NeonPalette.NeonPink
                )
            }
        }
    }
}

@Composable
fun VacancyCard(
    vacancy: Vacancy,
    isFav: Boolean,
    isApplied: Boolean,
    onFav: () -> Unit,
    onClick: () -> Unit
) {

    // показывает краткую информацию о вакансии
    val s = LocalStrings.current

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            }
    ) {
        Row {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        NeonPalette.NeonPurple.copy(alpha = 0.2f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = vacancy.logo,
                    color = NeonPalette.NeonCyan,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(
                modifier = Modifier.width(12.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = vacancy.company,
                        fontSize = 13.sp,
                        color = NeonPalette.NeonPurple,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (vacancy.isHot) {
                        Text(
                            text = " 🔥",
                            fontSize = 11.sp
                        )
                    }
                }

                Text(
                    text = vacancy.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Text(
                text = if (isFav) {
                    "♥"
                } else {
                    "♡"
                },
                fontSize = 24.sp,
                color = if (isFav) {
                    NeonPalette.NeonPink
                } else {
                    NeonPalette.GlassSecondary
                },
                modifier = Modifier.clickable {
                    onFav()
                }
            )
        }

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        Text(
            text = "${vacancy.salaryFrom / 1000}k – ${vacancy.salaryTo / 1000}k ₽",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = NeonPalette.NeonCyan
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Row {
            Text(
                text = vacancy.city,
                fontSize = 11.sp,
                color = NeonPalette.GlassSecondary,
                modifier = Modifier
                    .background(
                        NeonPalette.SurfaceLow,
                        RoundedCornerShape(4.dp)
                    )
                    .padding(4.dp)
            )

            Spacer(
                modifier = Modifier.width(8.dp)
            )

            Text(
                text = formatLabel(vacancy.format, s),
                fontSize = 11.sp,
                color = NeonPalette.GlassSecondary,
                modifier = Modifier
                    .background(
                        NeonPalette.SurfaceLow,
                        RoundedCornerShape(4.dp)
                    )
                    .padding(4.dp)
            )
        }

        if (isApplied) {
            Text(
                text = "✓ ${s.responseSent}",
                fontSize = 11.sp,
                color = NeonPalette.NeonGreen,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
fun VacancyDetailScreen(
    vacancy: Vacancy,
    isFav: Boolean,
    isApplied: Boolean,
    onBack: () -> Unit,
    onFav: () -> Unit,
    onApply: () -> Unit
) {

    // показывает подробную информацию о вакансии
    val s = LocalStrings.current

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopBar(
            title = vacancy.company,
            onBack = onBack
        ) {
            Text(
                text = if (isFav) {
                    "♥"
                } else {
                    "♡"
                },
                fontSize = 28.sp,
                color = if (isFav) {
                    NeonPalette.NeonPink
                } else {
                    NeonPalette.GlassSecondary
                },
                modifier = Modifier.clickable {
                    onFav()
                }
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = vacancy.title,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    lineHeight = 34.sp
                )
            }

            item {
                GlassCard {
                    Text(
                        text = "${vacancy.salaryFrom / 1000}k – ${vacancy.salaryTo / 1000}k ₽",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonPalette.NeonCyan
                    )

                    Text(
                        text = "${vacancy.city} • ${formatLabel(vacancy.format, s)}",
                        color = NeonPalette.GlassSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            item {
                GlassCard {
                    Text(
                        text = s.description,
                        fontSize = 12.sp,
                        color = NeonPalette.NeonPurple,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    Text(
                        text = vacancy.description,
                        fontSize = 14.sp,
                        color = NeonPalette.GlassSecondary
                    )
                }
            }

            item {
                GlassCard {
                    Text(
                        text = s.requirements,
                        fontSize = 12.sp,
                        color = NeonPalette.NeonCyan,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    vacancy.requirements.forEach { requirement ->
                        Text(
                            text = "• $requirement",
                            fontSize = 14.sp,
                            color = NeonPalette.GlassSecondary
                        )
                    }
                }
            }

            item {
                GlassCard {
                    Text(
                        text = s.benefits,
                        fontSize = 12.sp,
                        color = NeonPalette.NeonPink,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    vacancy.benefits.forEach { benefit ->
                        Text(
                            text = "• $benefit",
                            fontSize = 14.sp,
                            color = NeonPalette.GlassSecondary
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    NeonPalette.DeepSpace.copy(alpha = 0.9f)
                )
                .padding(20.dp)
                .padding(
                    WindowInsets.navigationBars.asPaddingValues()
                )
        ) {
            NeonButton(
                text = if (isApplied) {
                    s.responseSent
                } else {
                    s.respond
                },
                onClick = onApply,
                enabled = !isApplied
            )
        }
    }
}

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLogout: () -> Unit
) {

    // показывает настройки аккаунта
    val s = LocalStrings.current

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopBar(
            title = s.settings,
            onBack = onBack
        )

        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            NeonButton(
                text = s.logout,
                onClick = onLogout,
                outlined = true,
                accentColor = NeonPalette.NeonPink
            )
        }
    }
}